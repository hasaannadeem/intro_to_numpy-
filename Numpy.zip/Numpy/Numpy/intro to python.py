import numpy as np #alias
import matplotlib.pyplot as plt



# int x = 6; # C++,C

# float y = 7.0454;


# String s ='saad';

# char c = 'c';

x = 6
y = 7.0454
s = 'saad'
c = 'c'
 
print(type(x))
print(type(y))
print(type(s))
print(type(c))


# if (i>2){
# 	printf('%d',i);
# }
# else if {
	
# }

i=0
if i>=2:
	print(i)
elif i<2:
	print('less then 2')


# for (int i=1;i<10;i++){
# 	if(i%2==0){
# 	printf
# 	}
# }


# for i in range(0,100):  for (int i=0;i<100;i++){}
# 	print(i)

# for j in range(0,1000):
# 	if j%2==0:
# 		print(j)

a=5
b=6
c=7

def add(x,y,z):
	print(x+y+z)

add(a,b,c)